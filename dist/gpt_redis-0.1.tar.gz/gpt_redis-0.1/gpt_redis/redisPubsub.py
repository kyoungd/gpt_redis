import threading
import json
import redis
import logging
from typing import Callable, Optional
import uuid
import threading
import queue
from .redisUtil import RedisAccess

class RedisSubscriber(threading.Thread):
    def __init__(self, channels: list, r: Optional[redis.StrictRedis]=None, callback: Optional[Callable[[dict], None]]=None, isRunOnlyOnce: bool=False):
        super().__init__()
        self.redis = RedisAccess.create_connection(r)
        self.pubsub = self.redis.pubsub()
        self.pubsub.subscribe(channels)
        self.callback = callback
        self.isRunOnlyOnce = isRunOnlyOnce

    def work(self, package: dict):
        try:
            if self.callback is None:
                print(f"{package['channel']} : {package['data']}")
            else:
                data = json.loads(package['data'])
                result = self.callback(data)
                self.sync_message(data, result)
        except (json.JSONDecodeError, Exception) as e:
            logging.error(f"Failed to process package: {e}")

    def run(self):
        for package in self.pubsub.listen():
            if package['type'] != 'message':
                continue
            if package['data'] == "KILL":
                self.pubsub.unsubscribe()
                print("Unsubscribed and finished.")
                break
            self.work(package)
            if self.isRunOnlyOnce:
                break

    def sync_message(self, data: dict, result: dict) -> None:
        if 'return_channel' in data:
            return_data = { "message": "ok"} if result is None else result
            RedisPublisher(channel=data['return_channel']).publish(json.dumps(return_data))

    @staticmethod
    def Running(channels: list, callback: Optional[Callable[[dict], None]]=None, isRunOnlyOnce: bool=False):
        subscriber = RedisSubscriber(channels=channels, callback=callback, isRunOnlyOnce=isRunOnlyOnce)
        subscriber.start()


class RedisPublisher:
    def __init__(self, channel: str, r: Optional[redis.StrictRedis]=None):
        self.redis = RedisAccess.create_connection(r)
        self.channel = channel

    def publish(self, data: dict):
        package = json.dumps(data)
        self.redis.publish(self.channel, package)

    def stop_subscriber(self):
        self.redis.publish(self.channel, 'KILL')

    @staticmethod
    def Running(channel: str, data: dict, r: Optional[redis.StrictRedis]=None):
        publisher = RedisPublisher(channel=channel, r=r)
        publisher.publish(data)

class RedisCallbackSync:
    def __init__(self):
        self.queue = queue.Queue()

    def run(self, channel:str, data: dict) -> None:
        isCallbackComplete = threading.Event()

        def callback(data):
            isCallbackComplete.set()
            print(f"2. Received data: {data}")
            self.queue.put(data)

        publisher = RedisPublisher(channel=channel)
        data['channel'] = key
        data['return_channel'] = uuid.uuid4().hex
        publisher.publish(data)
        
        RedisSubscriber(channels=[data['return_channel']], callback=callback, isRunOnlyOnce=True).start()
        isCallbackComplete.wait()

    @property
    def result(self) -> dict:
        try:
            return self.queue.get(block=False)
        except queue.Empty:
            return None

    @staticmethod
    def Running(channel:str, data: dict) -> dict:
        rcb = RedisCallbackSync()
        rcb.run(channel=channel, data=data)
        return rcb.result

def run_subscriber(channel: str):

    def callback(data):
        print(f"1. Received data: {data}")

    RedisSubscriber(channels=[channel], callback=callback).start()

class RedisCallbackSync:

    def run(self, channel:str, data: dict) -> None:
        isCallbackComplete = threading.Event()

        def callback(data):
            isCallbackComplete.set()
            print(f"2. Received data: {data}")

        publisher = RedisPublisher(channel=channel)
        data['channel'] = key
        data['return_channel'] = uuid.uuid4().hex
        publisher.publish(data)
        
        RedisSubscriber(channels=[data['return_channel']], callback=callback, isRunOnlyOnce=True).start()
        isCallbackComplete.wait()

if __name__ == "__main__":
    key = "EVENT_TEST"
    data = {"data": {"message": "Hello, world!"}}

    def run_subscriber(channel: str):

        def callback(data):
            print(f"1. Received data: {data}")

        RedisSubscriber.Running(channels=[channel], callback=callback)

    run_subscriber(channel=key)
    print(RedisCallbackSync.Running(channel=key, data=data))
    print("Done")
