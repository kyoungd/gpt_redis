import os
from .redisHash import RedisHash
from dotenv import load_dotenv

# Load the .env file. By default, it looks for a file called .env in the same directory as the script.
# If your .env file is located elsewhere, pass the path to load_dotenv.
load_dotenv()

key = os.getenv("REDIS_KEY")
symbol = "ALL"
keys = RedisHash(key)
PUBSUB_KEYS = keys.get(symbol)
