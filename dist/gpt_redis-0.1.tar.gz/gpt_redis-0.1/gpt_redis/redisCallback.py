from redisPubsub import RedisPublisher, RedisSubscriber
import uuid
import threading

def run_subscriber(channel: str):

    def callback(data):
        print(f"1. Received data: {data}")

    RedisSubscriber(channels=[channel], callback=callback).start()

class RedisCallbackSync:

    def run(self, channel:str, data: dict) -> None:
        isCallbackComplete = threading.Event()

        def callback(data):
            isCallbackComplete.set()
            print(f"2. Received data: {data}")

        publisher = RedisPublisher(channel=channel)
        data['channel'] = key
        data['return_channel'] = uuid.uuid4().hex
        publisher.publish(data)
        
        RedisSubscriber(channels=[data['return_channel']], callback=callback, isRunOnlyOnce=True).start()
        isCallbackComplete.wait()

if __name__ == "__main__":
    key = "EVENT_TEST"
    data = {"data": {"message": "Hello, world!"}}

    run_subscriber(channel=key)
    RedisCallbackSync().run(channel=key, data=data)
    print("Done")
