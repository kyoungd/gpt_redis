from setuptools import setup, find_packages

setup(
    name="gpt_redis",
    version="0.1",
    packages=find_packages(),
    description="A simple example package",
    author="Your Name",
    author_email="your.email@example.com",
    url="http://github.com/kyoungd/gpt_redis",
    license="MIT",
)
